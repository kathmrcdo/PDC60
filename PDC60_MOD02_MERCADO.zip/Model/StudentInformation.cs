﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PDC60_MOD02.Model
{
    class StudentInformation
    {
        public int StudentID { get; set; }
        public string StudentName { get; set; }
        public int YearLevel { get; set; }
        public string Section { get; set; }

        public string CourseCode { get; set; }
        public string Course { get; set; }




    }
}
