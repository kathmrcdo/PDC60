﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;
using PDC60_MOD02.Model;
using Xamarin.Forms;
using static System.Collections.Specialized.BitVector32;

namespace PDC60_MOD02.ViewModel
{
    class StudentInformationViewModel:INotifyPropertyChanged
    {

        public StudentInformation StudentInfo { get; set; }
        public Command CommandInformationUpdate
        { get; set; }

        public int sID { get; set; }
        public string Sname { get; set; }
        public int yrlvl { get; set; }
        public string sec { get; set; }

        public string ccode { get; set; }
        public string crse { get; set; }

        public StudentInformationViewModel()
        {

            CommandInformationUpdate = new Command(() =>
            { 
            
            StudentInfo = new StudentInformation
            {
                StudentID = sID,
                StudentName = Sname,
                YearLevel= yrlvl,
                Section = sec,
                CourseCode = ccode,
                Course = crse,

            };

                OnPropertyChanged(nameof(StudentInfo));
            
            });


        }

        public event PropertyChangedEventHandler PropertyChanged;
        public void OnPropertyChanged(string propertyName)
        {
             PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
